# Estado del kit — 23 septiembre 2026

**Revisión en curso.** Las 20 piezas recientes se generaron mediante
`tools/generate_pixel_ui_assets.py`; su procedencia está registrada. Las otras
25 piezas conservan procedencias heredadas y estados pendientes de revisión.
No se consideran aceptadas sólo por haber sido exportadas o integradas.

El kit base se exportó, importó en Godot, convertido a estilos nueve segmentos
y mostrado en el catálogo. La UI de producción ya consume parte de estos
recursos, pero la migración de pantallas y la revisión visual siguen pendientes.

Los estados de experiencia, energía y vida al 0/25/50/75/100 % están en
`states/`. El llenado continuo sigue separado de la pista y listo para
recortarse por código.

La integración conserva las rutas, datos del jugador, lógica de compras y
navegación. Consulta `PLAN_IMPLEMENTACION_ASSETS.md` para el alcance y las
validaciones que faltan.

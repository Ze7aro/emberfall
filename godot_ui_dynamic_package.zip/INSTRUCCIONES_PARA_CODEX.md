# HUD dinámico para Godot 4

## Objetivo

Implementar el top y el footer como UI real de Godot, no como imágenes completas. Los PNG adjuntos sirven únicamente como guía visual. Los valores, botones, iconos y estados deben ser nodos independientes y actualizables.

## Estructura recomendada

```text
HUD (CanvasLayer)
└── SafeArea (MarginContainer)
    ├── TopHud (PanelContainer + TopHud.gd)
    └── NavigationFooter (PanelContainer + NavigationFooter.gd)
```

- `TopHud` se ancla arriba y ocupa todo el ancho.
- `NavigationFooter` se ancla abajo y contiene exactamente cinco botones mediante `HBoxContainer`.
- El contenido central del juego debe dejar márgenes equivalentes a las alturas de ambas barras.
- Activar `Project Settings > Display > Window > Stretch > Mode = canvas_items`.
- Diseñar tomando como base 1080 × 1920 en vertical y probar también relaciones 19.5:9 y 16:9.
- Aplicar márgenes de safe area en móviles con notch; el contenedor exterior debe recibir esos offsets.

## Uso

1. Crear un `CanvasLayer` llamado `HUD`.
2. Agregar dos `PanelContainer` como hijos y adjuntar `TopHud.gd` y `NavigationFooter.gd`.
3. En el inspector del footer, cargar cinco texturas PNG transparentes en `icons`, en el mismo orden que `entries`.
4. Conectar `navigation_requested` para cambiar de pantalla.
5. Actualizar el top desde el estado del jugador, nunca desde valores escritos en la escena:

```gdscript
@onready var top_hud: TopHud = $HUD/TopHud
@onready var footer: NavigationFooter = $HUD/NavigationFooter

func _ready() -> void:
	top_hud.set_level(player.level)
	top_hud.set_energy(player.energy, player.max_energy)
	top_hud.set_gold(player.gold)
	top_hud.set_gems(player.gems)
	top_hud.set_notifications(inbox.unread_count)
	footer.navigation_requested.connect(_on_navigation_requested)

func _on_navigation_requested(_index: int, id: StringName) -> void:
	match id:
		&"home": open_home()
		&"inventory": open_inventory()
		&"map": open_map()
		&"heroes": open_heroes()
		&"settings": open_settings()
```

## Requisitos para Codex

- No usar `footer_pixelart.png` ni `top_pixelart.png` como una captura completa interactiva.
- Usar `HBoxContainer`, `PanelContainer`, `Button`, `TextureRect`, `Label` y `ProgressBar`.
- Separar datos y presentación: un modelo/autoload emite cambios y el HUD llama a sus setters.
- Conservar cinco espacios iguales en el footer usando `SIZE_EXPAND_FILL`.
- Mantener iconos transparentes separados para poder reemplazarlos y animarlos.
- Añadir estados `normal`, `hover`, `pressed`, `selected` y `disabled` mediante `StyleBoxFlat` o un `Theme` compartido.
- En móvil, cada botón debe tener un área táctil mínima aproximada de 48 dp.
- Para pixel art, importar texturas con filtro desactivado y mipmaps desactivados; usar escalas enteras cuando sea posible.
- Animar selección y cambios de recursos con `Tween`, sin modificar el dato real desde la animación.

## Prompt listo para pegar a Codex

> Implementa en Godot 4 un HUD responsive con dos componentes reutilizables. El top debe mostrar dinámicamente nivel, energía actual/máxima, oro, joyas y cantidad de notificaciones. El footer debe tener exactamente cinco botones iguales, generados desde un array de configuración, con iconos PNG transparentes independientes y señal de navegación. No uses las imágenes de referencia como barras completas: solo toma de ellas la estética violeta oscura, bordes metálicos y acentos turquesa. Construye la UI con Control, PanelContainer, HBoxContainer, Button, TextureRect, Label y ProgressBar; usa anchors, size flags y StyleBoxFlat/Theme. Expón setters para los cinco valores del top, estado seleccionado del footer y señales para acciones. Respeta safe areas móviles, área táctil mínima de 48 dp y texturas pixel art sin filtrado. Integra `TopHud.gd` y `NavigationFooter.gd`, crea las escenas `.tscn` correspondientes y agrega una escena demo que permita cambiar valores y seleccionar los cinco botones.
